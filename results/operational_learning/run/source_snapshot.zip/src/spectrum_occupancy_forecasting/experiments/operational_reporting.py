"""Prediction-only reporting and numerical rehearsal for activity-count learning."""

import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .activity_counts import CountFilter, candidates
from .adaptive_reporting import regenerate as adaptive_report
from .fine_spectrum import sha, write_json
from .operational_selection import STRATEGIES


def numerical_suite(cfg, out):
    rng = np.random.default_rng(1701)
    cases = {
        "persistent": np.full(72, 0.2),
        "changing": np.r_[np.full(36, 0.05), np.full(36, 0.65)],
        "gaps": np.r_[np.full(24, 0.1), np.full(24, 0.7), np.full(24, 0.1)],
        "independent_future": rng.uniform(0.02, 0.8, 72),
        "all_idle": np.zeros(72),
        "all_busy": np.ones(72),
    }
    rows = []
    for low, high in ((801, 1601), (1601, 3201)):
        current = []
        for name, probabilities in cases.items():
            counts = rng.binomial(30, probabilities)
            mu = float(np.log((counts[:24].sum() + 0.5) / (24 * 30 - counts[:24].sum() + 0.5)))
            for h in cfg["count_half_lives_h"]:
                for sd in cfg["count_standard_deviations"]:
                    for rho in cfg["count_dispersions"]:
                        filters = [CountFilter(mu, h, sd, rho, nodes=n) for n in (low, high)]
                        differences = []
                        for j, count in enumerate(counts):
                            t = (j + 1) * 300
                            if not (name == "gaps" and 24 <= j < 48):
                                for state in filters:
                                    state.assimilate(t, int(count), 30)
                            forecasts = [
                                state.predict([t + 1200, t + 1500, t + 1800]) for state in filters
                            ]
                            differences.append(abs(forecasts[0] - forecasts[1]))
                        row = {
                            "case": name,
                            "half_life": h,
                            "sd": sd,
                            "rho": rho,
                            "low_nodes": low,
                            "high_nodes": high,
                            "maximum_forecast_difference": max(differences),
                        }
                        current.append(row)
        rows.extend(current)
        if max(r["maximum_forecast_difference"] for r in current) <= cfg["numerical_tolerance"]:
            selected = low
            break
    else:
        raise ValueError("grid convergence failed; do not execute real-data study")
    pd.DataFrame(rows).to_csv(out / "numerical_convergence.csv", index=False)
    write_json(
        out / "numerical_gate.json",
        {
            "passes": True,
            "selected_grid_nodes": selected,
            "tolerance": cfg["numerical_tolerance"],
            "synthetic": True,
        },
    )
    return selected


def regenerate(source, out, cfg):
    manifest_path = source / "manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        # During initial reporting only hashes available so far exist; published regeneration
        # verifies every input byte against the completed fitting manifest.
        if manifest.get("status") == "completed":
            for name, expected in manifest["artifact_hashes"].items():
                path = source / name
                if not path.exists() or sha(path) != expected:
                    raise ValueError(f"corrupted saved artifact: {name}")
    frame = pd.read_parquet(source / "predictions.parquet")
    expected = {"CC1_first": 439, "LW1_first": 239, "LW1_later": 81}
    for (recording, _scenario, _seed, _method), part in frame.groupby(
        ["recording", "scenario", "seed", "method"]
    ):
        if part.origin_s.duplicated().any() or (
            not part.synthetic.any() and len(part) != expected[recording]
        ):
            raise ValueError("missing or duplicated scored origins")
        if not np.isfinite(part.prediction).all():
            raise ValueError("failed forecasts must have explicit finite history fallback")
    for recording in frame.recording.unique():
        issued = pd.read_parquet(source / f"{recording}_candidate_forecasts.parquet")
        counts = issued.groupby("origin_s").candidate.nunique()
        if not (counts == len(candidates(cfg)) + 8).all():
            raise ValueError("incomplete candidate accounting")
        fallback = issued.fallback_reason.fillna("") != ""
        if not np.array_equal(
            issued.loc[fallback, "prediction"], issued.loc[fallback, "fixed_history"]
        ):
            raise ValueError("count safety fallback differs from fixed history")
    adaptive_report(
        source,
        out,
        cfg,
        candidate_factory=candidates,
        strategies=STRATEGIES,
        figure_function=figures,
    )
    path = out / "advancement.json"
    decision = json.loads(path.read_text())
    for strategy in decision["strategies"]:
        for recording in strategy["recordings"]:
            recording["minimum_fold_count_pass"] = (
                recording["recording"] == "LW1_later" or recording["fold_count"] >= 2
            )
        strategy["qualifies"] &= all(r["minimum_fold_count_pass"] for r in strategy["recordings"])
    qualified = [s for s in decision["strategies"] if s["qualifies"]]
    decision["status"] = "qualified" if qualified else "not_qualified"
    decision["flagship"] = "count" if qualified else "history"
    write_json(path, decision)


def figures(predictions, summary, uncertainty, out):
    plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False})
    prefix = "SYNTHETIC — " if predictions.synthetic.any() else "Exploratory development — "
    fig, axes = plt.subplots(3, 1, figsize=(10, 8), constrained_layout=True)
    for ax, recording in zip(axes, sorted(predictions.recording.unique()), strict=True):
        frame = predictions[
            (predictions.recording == recording) & (predictions.scenario == "clean")
        ]
        for method, label, color in (
            ("adaptive", "Selected count strategy", "#0072B2"),
            ("fixed_history", "Two-hour history", "#555555"),
        ):
            part = frame[frame.method == method].sort_values("origin_s")
            x = (part.origin_s - part.origin_s.min()) / 3600
            ax.plot(x, part.prediction, label=label, color=color, linewidth=1)
        part = frame[frame.method == "adaptive"].sort_values("origin_s")
        ax.plot(
            (part.origin_s - part.origin_s.min()) / 3600,
            part.y,
            color="#D55E00",
            label="Observed",
            alpha=0.7,
        )
        ax.set(title=recording, ylabel="Busy fraction", ylim=(-0.02, 1.02))
    axes[0].legend(ncol=3, fontsize=9)
    axes[-1].set_xlabel("Hours since first scored origin; +3 dB, target starts 15 minutes ahead")
    fig.suptitle(prefix + "forecasts saved before their outcomes")
    fig.savefig(out / "forecasts.png", dpi=150)
    plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), constrained_layout=True)
    clean = summary[(summary.method == "adaptive") & (summary.scenario == "clean")]
    x = np.arange(len(clean))
    axes[0].bar(x - 0.18, clean.mss_vs_fixed * 100, 0.36, color="#0072B2", label="Fixed history")
    axes[0].bar(
        x + 0.18, clean.mss_vs_selected * 100, 0.36, color="#E69F00", label="Selected history"
    )
    axes[0].set_xticks(x, clean.recording, rotation=15)
    axes[0].axhline(5, linestyle="--", color="black")
    axes[0].axhline(0, color="gray")
    axes[0].set(ylabel="MSE reduction (%)", title="Clean performance; dashed line = 5%")
    axes[0].legend(fontsize=9)
    for recording, frame in summary[summary.method == "adaptive"].groupby("recording"):
        axes[1].plot(frame.scenario, 1 - frame.mss_vs_fixed, marker=".", label=recording)
    axes[1].axhline(1.1, color="black", linestyle="--")
    axes[1].set(ylabel="MSE / same-scenario fixed history MSE", title="Sensor degradation")
    axes[1].tick_params(axis="x", rotation=80, labelsize=8)
    axes[1].legend(fontsize=8)
    fig.suptitle(prefix + "mandatory comparisons")
    fig.savefig(out / "performance.png", dpi=150)
    plt.close(fig)
    fig, axes = plt.subplots(3, 1, figsize=(8, 8), constrained_layout=True)
    for ax, recording in zip(axes, sorted(predictions.recording.unique()), strict=True):
        frame = uncertainty[
            (uncertainty.recording == recording)
            & (uncertainty.method == "adaptive")
            & (uncertainty.scenario == "clean")
            & (uncertainty.reference == "fixed")
        ]
        ax.plot(
            frame.block_s / 3600, frame.difference_lo, "o-", color="#0072B2", label="95% limits"
        )
        ax.plot(frame.block_s / 3600, frame.difference_hi, "o--", color="#0072B2")
        ax.axhline(0, color="gray")
        ax.set(title=recording, xticks=[2, 4, 8, 12], ylabel="Paired MSE difference")
    axes[-1].set_xlabel("Block hours; omitted below four blocks; fewer than ten = weak evidence")
    fig.suptitle(prefix + "block-length sensitivity")
    fig.savefig(out / "block_sensitivity.png", dpi=150)
    plt.close(fig)
