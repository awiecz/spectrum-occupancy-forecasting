"""Presentation for the fixed two-family study; numerical reports reuse audited utilities."""

import matplotlib.pyplot as plt

from .adaptive_reporting import regenerate as adaptive_regenerate
from .residual_state_space import STRATEGIES, candidates


def figures(predictions, summary, uncertainty, out):
    plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False})
    prefix = "SYNTHETIC — " if predictions.synthetic.any() else "Exploratory — "
    recordings = sorted(predictions.recording.unique())
    fig, axes = plt.subplots(
        len(recordings), 1, figsize=(10, 8), constrained_layout=True, squeeze=False
    )
    for ax, recording in zip(axes[:, 0], recordings, strict=True):
        group = predictions[
            (predictions.recording == recording) & (predictions.scenario == "clean")
        ]
        for family, color in (("level", "#0072B2"), ("trend", "#009E73")):
            part = group[(group.strategy == family) & (group.method == "adaptive")].sort_values(
                "origin_s"
            )
            x = (part.origin_s - part.origin_s.min()) / 3600
            ax.plot(x, part.prediction, label=family, color=color)
        ax.plot(x, part.fixed_history, label="Two-hour history", color="#555555", alpha=0.7)
        ax.plot(x, part.y, label="Observed", color="#D55E00", alpha=0.7)
        ax.set(title=recording, ylabel="Busy fraction", ylim=(-0.02, 1.02))
    axes[0, 0].legend(ncol=4, fontsize=9)
    axes[-1, 0].set_xlabel("Hours since first scored origin; +3 dB, 15-minute targets")
    fig.suptitle(prefix + "forecasts issued before outcomes")
    fig.savefig(out / "forecasts.png", dpi=150)
    plt.close(fig)
    clean = summary[(summary.scenario == "clean") & (summary.method == "adaptive")]
    fig, ax = plt.subplots(figsize=(9, 4), constrained_layout=True)
    (clean.pivot(index="strategy", columns="recording", values="mss_vs_fixed") * 100).plot.bar(
        ax=ax
    )
    ax.axhline(0, color="black", linewidth=0.7)
    ax.axhline(5, linestyle="--", color="black")
    ax.set(
        ylabel="MSE reduction vs two-hour history (%)",
        xlabel="Model family",
        title=prefix + "negative values mean higher error",
    )
    ax.tick_params(axis="x", rotation=0)
    fig.savefig(out / "clean_skill.png", dpi=150)
    plt.close(fig)
    fig, axes = plt.subplots(3, 1, figsize=(11, 9), constrained_layout=True)
    for ax, recording in zip(axes, recordings, strict=True):
        part = summary[(summary.recording == recording) & (summary.method == "adaptive")]
        for strategy, data in part.groupby("strategy"):
            ax.plot(data.scenario, 1 - data.mss_vs_fixed, marker=".", label=strategy)
        ax.axhline(1.1, color="black", linestyle="--")
        ax.set(title=recording, ylabel="MSE / same-scenario history MSE")
        ax.tick_params(axis="x", rotation=25, labelsize=8)
    axes[0].legend()
    fig.suptitle(prefix + "sensor-specific delivered feedback; paired seed losses")
    fig.savefig(out / "robustness.png", dpi=150)
    plt.close(fig)
    fig, axes = plt.subplots(3, 1, figsize=(9, 9), constrained_layout=True)
    for ax, recording in zip(axes, recordings, strict=True):
        part = uncertainty[
            (uncertainty.recording == recording)
            & (uncertainty.method == "adaptive")
            & (uncertainty.scenario == "clean")
            & (uncertainty.reference == "fixed")
        ]
        for strategy, data in part.groupby("strategy"):
            color = "#0072B2" if strategy == "level" else "#009E73"
            ax.plot(
                data.block_s / 3600, data.difference_lo, color=color, marker=".", label=strategy
            )
            ax.plot(
                data.block_s / 3600, data.difference_hi, color=color, marker=".", linestyle="--"
            )
        ax.axhline(0, color="black", linewidth=0.7)
        ax.set(title=recording, xlabel="Block length (hours)", ylabel="Paired MSE difference")
        ax.set_xticks([2, 4, 8, 12])
    axes[0].legend()
    fig.suptitle(prefix + "intervals suppressed below four blocks; <10 blocks is weak")
    fig.savefig(out / "block_sensitivity.png", dpi=150)
    plt.close(fig)


def regenerate(source, out, cfg):
    return adaptive_regenerate(
        source,
        out,
        cfg,
        candidate_factory=candidates,
        strategies=STRATEGIES,
        figure_function=figures,
    )
